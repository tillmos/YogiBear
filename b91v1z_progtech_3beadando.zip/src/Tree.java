import java.awt.*;

public class Tree extends Sprite {
    public Tree(int x, int y, int width, int height, Image image) {
        super(x, y, width, height, image);
    }
}
