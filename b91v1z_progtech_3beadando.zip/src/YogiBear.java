public class YogiBear {

    public static void main(String[] args){
        YogiBearGUI gui = new YogiBearGUI();
    }
}
