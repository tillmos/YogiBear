import java.awt.*;

public class Rock extends Sprite{

    public Rock(int x, int y, int width, int height, Image image) {
        super(x, y, width, height, image);
    }

}
