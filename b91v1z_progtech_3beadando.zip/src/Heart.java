import java.awt.*;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Heart extends Sprite {

    public Heart(int x, int y, int width, int height, Image image) {
        super(x, y, width, height, image);

    }


}
